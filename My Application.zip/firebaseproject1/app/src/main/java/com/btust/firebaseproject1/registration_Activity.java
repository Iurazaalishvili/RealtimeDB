package com.btust.firebaseproject1;

import android.app.Activity;

public class registration_Activity extends Activity {
}
